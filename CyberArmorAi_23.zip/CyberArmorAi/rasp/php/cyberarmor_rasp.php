<?php
// Canonical CyberArmor bootstrap.
