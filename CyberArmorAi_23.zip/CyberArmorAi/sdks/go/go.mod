module github.com/cyberarmor-ai/cyberarmor-go

go 1.22

require (
	github.com/golang-jwt/jwt/v5 v5.2.1
)
